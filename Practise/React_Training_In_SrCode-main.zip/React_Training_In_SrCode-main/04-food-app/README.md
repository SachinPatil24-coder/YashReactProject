# Food App

This project is desined to practice debugging skills and implement what you have learned in the previous sessions. 

## How to get this project up and running in your machine.
-	Create a project: name it as food app (npx create-react-app food-app)
-	Delete your application src folder, Copy the src folder of this app and paste in your app.
-	run and test your app using (npm start) command

## Corrections in existing code

-	There are certain incomplete code. Which i added. Your job is to bring the application in proper shape.
-	If you see the Cart button, it is not correct, check the code, understand and bring it into shape.
-	MealItems should actually display :  Meal item name, description and price. See where it is available and how it can be shown.
-	Do not use any external code, you just need to correct the code from the given project. 

