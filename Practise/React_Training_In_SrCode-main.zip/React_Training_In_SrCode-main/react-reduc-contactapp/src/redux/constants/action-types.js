export const ActionTypes = {
  ADD_CONTACT: "ADD_CONTACT",
  GET_CONTACTS: "GET_CONTACTS",
};
